import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def handler(event, context):
    ec2         = boto3.client('ec2')
    instance_id = os.environ['INSTANCE_ID']
    action      = os.environ['ACTION']

    if action == 'start':
        ec2.start_instances(InstanceIds=[instance_id])
        logger.info(f'Started EC2 instance {instance_id}')
    elif action == 'stop':
        ec2.stop_instances(InstanceIds=[instance_id])
        logger.info(f'Stopped EC2 instance {instance_id}')
    else:
        raise ValueError(f'Unknown action: {action}')

    return {'status': 'ok', 'action': action, 'instance_id': instance_id}
